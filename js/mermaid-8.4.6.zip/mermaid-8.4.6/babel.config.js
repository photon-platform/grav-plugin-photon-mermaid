module.exports = {
  presets: [
    [
      '@babel/preset-env',
      {
        targets: "defaults, ie >= 11, current node"
      }
    ]
  ]
}
