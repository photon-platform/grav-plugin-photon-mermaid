/* eslint-env jest */
import { imgSnapshotTest } from '../../helpers/util.js';

describe('Sequencediagram', () => {
  // it('should render a simple git graph', () => {
  //   imgSnapshotTest(
  //     `
  //   gitGraph:
  //     commit
  //     branch newbranch
  //     checkout newbranch
  //     commit
  //     commit
  //     checkout master
  //     commit
  //     commit
  //     merge newbranch`,
  //     { logLevel: 0 }
  //   );
  // });
});
